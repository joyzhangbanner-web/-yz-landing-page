# 着陆页配置指南

欢迎使用您的 YZ 展示架着陆页! 本文档将指导您完成最后的配置步骤。

## 📋 您的信息

- **Logo:** YZ
- **邮箱:** joyzhangbanner@gmail.com
- **WhatsApp:** +8618120571001
- **着陆页文件:** landing_page.html
- **样式文件:** styles.css

## ✅ 已完成的配置

以下信息已经在 HTML 文件中更新:
- ✓ Logo 已更改为 "YZ"
- ✓ WhatsApp 链接已更新为 +8618120571001
- ✓ 表单已配置为使用 Formspree (需要最后一步配置)

## 🔧 最后一步: 配置 Formspree (5分钟)

### 为什么需要 Formspree?

您的着陆页是一个**静态 HTML 文件**,无法直接发送邮件。Formspree 是一个免费的第三方服务,它会:
1. 接收您的表单提交
2. 自动将数据发送到您的邮箱 (joyzhangbanner@gmail.com)
3. 无需编写任何代码

### 配置步骤

#### 第 1 步: 注册 Formspree 账户

1. 访问 https://formspree.io/
2. 点击 "Sign Up" (注册)
3. 使用您的邮箱 (joyzhangbanner@gmail.com) 注册
4. 完成邮箱验证

#### 第 2 步: 创建新表单

1. 登录 Formspree 后,点击 "Create" 或 "New Form"
2. 输入表单名称,例如: "YZ Landing Page Inquiry"
3. 点击 "Create"

#### 第 3 步: 获取 Form Endpoint

1. Formspree 会为您生成一个唯一的 **Form ID** (例如: `mbjwqpqk`)
2. 您的完整 Endpoint URL 将是: `https://formspree.io/f/mbjwqpqk`

#### 第 4 步: 更新 HTML 文件

1. 打开 `landing_page.html` 文件
2. 找到这一行 (大约在第 84 行):
   ```html
   <form class="contact-form" id="contactForm" action="https://formspree.io/f/YOUR_FORMSPREE_ID" method="POST">
   ```
3. 将 `YOUR_FORMSPREE_ID` 替换为您从 Formspree 获取的 Form ID
   - 例如,如果您的 Form ID 是 `mbjwqpqk`,修改后应该是:
   ```html
   <form class="contact-form" id="contactForm" action="https://formspree.io/f/mbjwqpqk" method="POST">
   ```
4. 保存文件

#### 第 5 步: 测试表单

1. 上传修改后的 `landing_page.html` 和 `styles.css` 到您的网站服务器
2. 打开着陆页,填写并提交表单
3. 检查您的邮箱 (joyzhangbanner@gmail.com) 是否收到表单数据

## 📱 产品集合图

在 HTML 文件中,产品展示区域目前显示的是一个占位符。为了展示真实的产品图片:

1. 将您的产品集合图片保存为 `product_showcase.jpg` (或任何您喜欢的名称)
2. 上传到与 `landing_page.html` 相同的目录
3. 在 HTML 文件中找到这一行 (大约在第 68 行):
   ```html
   <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 300'%3E%3Crect fill='%23f5f5f5' width='400' height='300'/%3E%3Ctext x='200' y='150' font-size='24' text-anchor='middle' fill='%23999' font-family='Arial'%3E[Product Showcase Image]%3C/text%3E%3C/svg%3E" alt="Product Showcase">
   ```
4. 将其替换为:
   ```html
   <img src="product_showcase.jpg" alt="Product Showcase">
   ```

## 🌐 部署到网络

### 选项 A: 使用免费托管服务 (推荐新手)

**Netlify (最简单)**
1. 访问 https://netlify.com
2. 使用 GitHub/Google 账户登录
3. 拖拽您的 `landing_page.html` 和 `styles.css` 到 Netlify
4. 您的着陆页将立即获得一个公开 URL

**Vercel**
1. 访问 https://vercel.com
2. 使用 GitHub/Google 账户登录
3. 上传您的文件
4. 获得公开 URL

### 选项 B: 使用您自己的服务器

1. 将 `landing_page.html` 和 `styles.css` 上传到您的服务器
2. 访问对应的 URL

## 📊 表单字段说明

表单包含以下字段,用户需要填写:

| 字段 | 说明 |
| --- | --- |
| Nombre Completo | 客户全名 |
| Email | 客户邮箱 |
| Teléfono / WhatsApp | 客户电话或 WhatsApp |
| Nombre de la Empresa | 客户公司名称 |
| Producto de Interés | 客户感兴趣的产品 (下拉菜单) |
| Cantidad Aproximada | 客户需要的大约数量 |
| Mensaje | 可选的额外信息 |

## 🎨 自定义着陆页

如果您想修改着陆页的外观,可以编辑 `styles.css` 文件。以下是一些常见的自定义:

### 修改品牌色

在 `styles.css` 文件的顶部,找到:
```css
:root {
    --primary-color: #1a365d;      /* 深蓝色 */
    --accent-color: #f97316;       /* 橙色 */
    --text-color: #333;
    --light-gray: #f5f5f5;
    --border-color: #e0e0e0;
    --white: #ffffff;
}
```

您可以修改这些颜色值。例如:
- `--primary-color: #1a365d` 改为 `--primary-color: #003366` (不同的蓝色)
- `--accent-color: #f97316` 改为 `--accent-color: #ff6b35` (不同的橙色)

### 修改文本内容

在 `landing_page.html` 中,您可以直接修改任何文本内容,例如:
- 标题、副标题
- 价值主张
- 按钮文本

## ⚠️ 常见问题

**Q: 表单提交后没有收到邮件?**
A: 检查以下几点:
1. 确认您已正确替换 Formspree Form ID
2. 检查垃圾邮件文件夹
3. 在 Formspree 仪表板中检查是否有错误日志

**Q: 我可以修改表单字段吗?**
A: 可以。在 HTML 文件中找到 `<form>` 部分,添加或删除 `<div class="form-group">` 块即可。

**Q: 我想添加更多的产品选项?**
A: 在 HTML 文件中找到 `<select id="product" name="product">`,添加更多 `<option>` 标签。

## 📞 技术支持

如果您遇到任何问题,请参考:
- Formspree 文档: https://formspree.io/docs
- Netlify 文档: https://docs.netlify.com
- HTML/CSS 基础: https://www.w3schools.com

---

**祝您的着陆页运营顺利!** 🚀
